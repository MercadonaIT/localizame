import UIKit
protocol Localizable: CustomStringConvertible {
    var rawValue: String { get }
}

extension Localizable {
    var localized: String {
        return NSLocalizedString(self.rawValue, comment: "")
    }

    var uppercased: String {
        return self.localized.uppercased()
    }

    var description: String {
        return self.localized
    }

    func localized(with: CVarArg...) -> String {
        let text = String(format: self.localized, arguments: with)
        return text
    }
}

extension String {
    public enum banned: String, Localizable {
            case desc = "banned_desc"
            case title = "banned_title"
    }
    public enum biometry: String, Localizable {
            case cancel_button_title = "biometry_cancel_button_title"
    }
    public enum certificate: String, Localizable {
            case direct_debit_downloadError = "certificate_direct_debit_downloadError"
            case leave_and_cancellations = "certificate_leave_and_cancellations"
            case leave_and_cancellations_pregnancy_description = "certificate_leave_and_cancellations_pregnancy_description"
    }
    public enum filter: String, Localizable {
            case title = "filter_title"
            case videos = "filter_videos"
    }
    public enum healthCheck: String, Localizable {
            case description = "healthCheck_description"
            case title = "healthCheck_title"
    }
    public enum terms: String, Localizable {
            case rules_sharedContent = "terms_rules_sharedContent"
            case rules_title = "terms_rules_title"
            case rules_user_responsaility = "terms_rules_user_responsaility"
    }
}